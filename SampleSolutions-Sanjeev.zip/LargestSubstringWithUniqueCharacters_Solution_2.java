import java.util.LinkedHashMap;
import java.util.Map;

public class FindLongestSubstringChar {

	public static void main(String[] args) {

		String input = "aaabcbdeaf";

		findLongestSubstringChar(input);

	}

	private static void findLongestSubstringChar(String input) {

		char[] array = input.toCharArray();
		String substring = null;
		int length = 0;

		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
		for (int i = 0; i < array.length; i++) {
			char ch = array[i];
			if (!map.containsKey(ch)) {
				map.put(ch, i);
			} else {
				i = map.get(ch);

				map.clear();
			}
			if (map.size() > length) {
				length = map.size();

				substring = map.keySet().toString();
			}
		}

		System.out.println("The longest substring with unique chars : " + substring);

		System.out.println("The longest Substring Length with unique chars : " + length);

	}

}
