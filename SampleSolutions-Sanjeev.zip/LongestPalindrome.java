
public class LongestPalindrome {
	public static void main(String[] args) {

		String input = "aabaaccddccefe";
		String result = findLongestPalindrome(input);
		System.out.println(result);
	}

	private static String findLongestPalindrome(String input) {
		if (input.isEmpty() || input == null) {
			return null;
		}

		if (input.length() == 1) {
			return input;
		}

		String palindrome = input.substring(0, 1);

		for (int i = 0; i < input.length(); i++) {
			String t = getPalindrome(input, i, i);
			if (t.length() > palindrome.length()) {
				palindrome = t;
			}
			
			String t1 = getPalindrome(input, i, i+1);
			if (t1.length() > palindrome.length()) {
				palindrome = t1;
			}
		}
		return palindrome;
	}

	private static String getPalindrome(String input, int i, int j) {
		while (i >= 0 && j <= input.length() - 1 && input.charAt(i) == input.charAt(j)) {
			i--;
			j++;
		}
		return input.substring(i + 1, j);
	}
}
