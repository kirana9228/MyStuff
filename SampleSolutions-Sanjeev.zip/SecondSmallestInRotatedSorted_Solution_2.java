
public class FindNthSmallestInSortedRotatedArray {
	public static void main(String[] args) {
		// sorted rotated array
		int[] input = { 15, 16,17, 11, 12, 13, 14 };
		// 2nd smallest element
		int position = 2;

		int minIndex = findMin(input, 0, input.length - 1);

		int finalIndex = minIndex + position - 1;
		// if min element present after index 0
		if (finalIndex >= input.length) {
			finalIndex = (minIndex + position) - input.length - 1;
		}

		if (position <= input.length && finalIndex >= 0) {
			System.out.println(input[finalIndex]);
		} else {
			System.out.println("Array index is out of bound...");
		}
	}

	// used binary search concept
	private static int findMin(int[] input, int start, int end) {
		if (start == end) {
			return start;
		}
		
		if (input[start] < input[end]) {
			return start;
		}

		int mid = (end - start) / 2;

		if (input[start] <= input[mid]) {
			return findMin(input, start, mid-1);
		} else {
			return findMin(input, mid, end);
		}

	}
}
