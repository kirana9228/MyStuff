
public class PascalTriangle {
	public static void main(String[] args) {

		int DEFAULT_ROWS = 10;
		int row = 5;
		int position = 2;
		int element  = getElementFromPascalTree(DEFAULT_ROWS,row,position);
		System.out.println("At row:"+row+", position:"+position+"-->"+element);
	}

	private static int getElementFromPascalTree(int default_rows,int row,int position) {
		int findElement= 0;
		for(int i=0;i<default_rows;i++){
			for(int j= 0;j<=i;j++){
				int k = factorial(i)/(factorial(j)*factorial(i-j));
				System.out.print(k);
				if(row==i+1 && position==j+1){
					findElement = k;
				}
			}
			System.out.println();
		}
		return findElement;
	}

	private static int factorial(int n) {
		if(n==0)
			return 1;
		return n*factorial(n-1);
	}
}


