import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupAnagrams {
	public static void main(String[] args) {
		List<String> anagrams = Arrays.asList("ABC", "CBA", "BCA", "ABD", "DBA");

		Map<String, List<String>> anagramGroup = new HashMap<>();

		anagramGroup = findAnagramGroup(anagrams);
		System.out.println(anagramGroup);

	}

	private static Map<String, List<String>> findAnagramGroup(List<String> anagrams) {
		Map<String, List<String>> temp = new HashMap<>();

		for (String str : anagrams) {
			List<String> values = new ArrayList<>();
			// sort string chars
			char[] tempArray = str.toCharArray();
			Arrays.sort(tempArray);
		
			String key = String.valueOf(tempArray);

			if (temp.containsKey(key)) {
				values = temp.get(key);
				values.add(str);
			} else {
				values.add(str);
			}
			temp.put(key, values);
		}
		return temp;
	}
}
