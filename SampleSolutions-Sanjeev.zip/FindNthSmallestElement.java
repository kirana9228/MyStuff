
public class FindNthSmallestElement {

	public static void main(String[] args) {
		//unsorted array
		int[] input = { 5, 3, 1, 4, 7, 8 };

		//2nd smallest element
		int element = findNthSmallestElement(input, 2);
		System.out.println(element);
	}

	//using Selection sort here
	private static int findNthSmallestElement(int[] input, int n) {
		if (n <= 0 || n > input.length) {
			return -1;
		}
		int index = 0;
		for (int i = 0; i < n; i++) {
			index = i;
			for (int j = i + 1; j < input.length; j++) {
				if (input[j] < input[index]) {
					index = j;
				}
			}
			int temp = input[index];
			input[index] = input[i];
			input[i] = temp;

		}

		return input[n - 1];
	}
}
