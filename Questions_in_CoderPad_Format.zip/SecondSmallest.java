import java.io.*;
import java.util.*;

/*
 * This program finds second largest element in a numeric array
 *
 * eg.
 * findSecondSmallest({1,2,3,4,5,6}) == 2
 */

class Solution {
  
  static int findSecondSmallest(int[] inputArray){
    //your code goes here
    return 0;
  }
  
  public static void main(String[] args) {
    
    //Find second smallest element in unsorted array
    //Eg: Input - 2,4,5,1,3,8  Output - 2 
    
    if(findSecondSmallest(new int[]{1,2,3,4,5,6}) == 2 && 
	findSecondSmallest(new int[]{2,8,9,1,10,0}) == 1){
      System.out.println("Test Passed");
    }else{
      System.out.println("Test Failed");
    }   
  }
}