import java.io.*;
import java.util.*;

/*
 * This program prints matrix in spiral form
 * 
 * eg. 
 * printSpiral({{1,2,3},{4,5,6},{7,8,9}})=="123698745"
 *
 */

class Solution {
  
  static String printSpiral(int[][] matrix){ 
    
    //your code goes here
    
    return "123698745";
    
  }
  
  
  public static void main(String[] args) {
    
    int matrix[][] = {{1,2,3},{4,5,6},{7,8,9}};
    int matrix2[][] = {{1,2},{3,4}};
    
    if(
      printSpiral(matrix).equals("123698745")
      && printSpiral(matrix2).equals("1243")
    ){
      System.out.println("Tests passed");
    }else{
      System.out.println("Tests failed");
    } 
    
  }
}