import java.io.*;
import java.util.*;

/*
 * This program searches for largest substring with unique characters
 * 
 * eg. "aaabcbdeaf"
 * findFirstUniqueCharacter("aaabcbdeaf")=="cbdeaf"
 *
 */

class Solution {
  
  static String largestSubstring(String inputString){ 
    
    //your code goes here
    
    return "ddddd";
    
  }
  
  
  public static void main(String[] args) {
    
    if(
      largestSubstring("aaabcbdeaf").equals("cbdeaf")
      && largestSubstring("abcdb").equals("cdb")
    ){
      System.out.println("Tests passed");
    }else{
      System.out.println("Tests failed");
    }
    
    
  }
}