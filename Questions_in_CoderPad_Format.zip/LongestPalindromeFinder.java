import java.io.*;
import java.util.*;

/*
 * This program searches for largest palindrome in a given string
 * 
 * eg. "9912321456"
 * longestPalindromeString("9912321456")=="12321"
 *
 */

class Solution {
  
  static String longestPalindromeString(String inputString){ 
    
    //your code goes here
    
    return "";
    
  }
  
  
  public static void main(String[] args) {
    
    if(
      longestPalindromeString("9912321456").equals("12321")
      && longestPalindromeString("12233213").equals("2332")
    ){
      System.out.println("Tests passed");
    }else{
      System.out.println("Tests failed");
    } 
    
  }
}