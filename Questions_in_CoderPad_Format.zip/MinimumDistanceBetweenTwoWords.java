import java.io.*;
import java.util.*;

/*
 * This program searches given two words in a string and calculates distance
 * between middle characters. Find minimum distance between words.
 * 
 * eg. "this is an example"
 * minDistance("this","is")==4
 *
 */

class Solution {
  
//  static String p = "the ABC the DEF ABCD";
  static String p = "One office for loan of money for customs calc of goods , "
	  		+ "which by a plain method be so ordered that "
	  		+ "the merchant might with ease pay the highest "
	  		+ "customes down, and so, by allowing the bank "
	  		+ "four per cent advance, be first to secure "
	  		+ "the $10 per cent which the king allows for prompt";
  
  public static int getDistance(String str1, String str2){
    
	//your code goes here

    return 0;
       
  }
  
  public static void main(String[] args) {
    
    if(
    	getDistance("office","loan") == 10 && 
		getDistance("customs","the") == 65 &&
		getDistance("plain", "method") == 7 &&
		getDistance("calc", "goods") == 8){
    	System.out.println("Tests passed");
    }else{
    	System.out.println("Tests failed");
    }
    		  
  }
}
