import java.io.*;
import java.util.*;

/*
 * This program adda two fraction a/b and c/d and print answer in simplest form.
 * 
 * eg. 
 * addFraction({2,3},{5,2})== {19,6}
 *
 */

class Solution {
  
  static int[] addFraction(int[] arr1, int[] arr2){
      
    //your code goes here
    
      return new int[] {0,0};
    }
  
  
   public static void main(String[] args) {
      
    int[][] input1 = {{2,3},{5,2}};
    int[][] input2 = {{2,0},{5,0}};
    int[][] input3 = {{3,15},{6,15}};
    int[][] input4 = {{-2,3},{5,2}};
    
    
      if(
      Arrays.equals(addFraction(input1[0], input1[1]),new int[] {19,6}) &&
      Arrays.equals(addFraction(input3[0], input3[1]),new int[] {3,5}) &&
      Arrays.equals(addFraction(input4[0], input4[1]),new int[] {11,6}) 
      ){
        System.out.println("Test Passed");
      }else{
        System.out.println("Test failed");
      }
      
    }  
}
