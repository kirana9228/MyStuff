import java.io.*;
import java.util.*;

/*
 * This program searches for the first unique character in the string
 * 
 * eg. "aaabcbdeaf"
 * findFirstUniqueCharacter("aaabcbdeaf")=='c'
 *
 */

class Solution {
  
  static char firstUnique(String inputString){ 
    
    //your code goes here
    
    return 'c';
    
  }
  
  
  public static void main(String[] args) {
    
    if(
      firstUnique("aaabcbdeaf")== 'c'
      && firstUnique("abeccdb") == 'e'
    ){
      System.out.println("Tests passed");
    }else{
      System.out.println("Tests failed");
    } 
    
  }
}